﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersonScript : MonoBehaviour
{
    public Vector3 target;
    public bool followTarget = false;
    public Vector3 wanderPoint;
    public float timer = 0;
    public string state = "idle";
    public Rigidbody2D rb;
    public Vector3 direction;
    public Animator Anim;
    public float speed = 200f;
    public GameObject sprite;
    public GameObject lookAt;

    public Sprite normalSprite;
    public List<Sprite> disappointedSprites;
    public List<Color> possibleColors;

    private void Awake()
    {
        wanderPoint = transform.position;
        timer = Random.Range(1.0f, 2.0f);
        rb = GetComponent<Rigidbody2D>();
        if (followTarget)
        {
            state = "follow";
        }
        sprite.GetComponent<SpriteRenderer>().color = possibleColors[Random.Range(0,possibleColors.Count)];
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (state == "idle")
        {
            rb.velocity = Vector2.Lerp(rb.velocity, Vector2.zero,0.125f);
            Anim.SetInteger("Anim", 0);
            if (timer <= 0)
            {
                timer = Random.Range(0.1f,0.5f);
                if ((wanderPoint - transform.position).magnitude < 2)
                {
                    direction = ((transform.position + new Vector3(Random.Range(-1.0f, 1.0f), Random.Range(-1.0f, 1.0f), 0)) - (transform.position - new Vector3(0, 0.5f, 0))).normalized;
                } else
                {
                    direction = (wanderPoint - (transform.position - new Vector3(0, 0.5f, 0))).normalized;
                }
                state = "wander";
            }
        } else if (state == "wander")
        {
            rb.velocity = Vector2.Lerp(rb.velocity, direction * speed * Time.deltaTime, 0.125f);
            Anim.SetInteger("Anim", 1);
            if (timer <= 0)
            {
                timer = Random.Range(1.0f, 5.0f);
                state = "idle";
            }
        } else if (state == "shocked")
        {
            rb.velocity = Vector2.Lerp(rb.velocity, Vector2.zero, 0.09f);
            if (timer <= 0)
            {
                timer = Random.Range(1.0f, 5.0f);
                if (followTarget == true)
                {
                    state = "follow";
                } else
                {
                    state = "idle";
                }
            }
        } else if (state == "follow")
        {
            if ((target - transform.position - new Vector3(0, 0.5f, 0)).magnitude > 0.25f)
            {
                rb.velocity = Vector2.Lerp(rb.velocity, (target - transform.position - new Vector3(0, 0.5f, 0)).normalized * speed * Time.deltaTime, 0.125f);
            } else
            {
                rb.velocity = Vector2.Lerp(rb.velocity, Vector2.zero, 0.125f);
            }
        }

        if (state != "shocked")
        {
            sprite.GetComponent<SpriteRenderer>().sprite = normalSprite;
        }

        if (followTarget == false)
        {
            if (rb.velocity.x > 0)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = false;
            }
            else if (rb.velocity.x < 0)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = true;
            }
        } else
        {
            if (target.x - transform.position.x > 0)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = false;
            }
            else if (target.x - transform.position.x < 0)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = true;
            }
        }
    }
}
