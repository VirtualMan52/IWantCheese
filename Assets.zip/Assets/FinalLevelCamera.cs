﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalLevelCamera : MonoBehaviour
{
    public GameObject plr;
    public float upBoundary;
    public float downBoundary;

    void Update()
    {
        if (plr.transform.position.y > downBoundary && plr.transform.position.y < upBoundary)
        {
            transform.position = Vector3.Lerp(transform.position, new Vector3(0f,plr.transform.position.y,-10),0.125f);
        }
    }
}
