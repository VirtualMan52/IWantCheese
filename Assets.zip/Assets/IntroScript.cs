﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class IntroScript : MonoBehaviour
{
    public PlayerScript FakeRedBall;
    public GameObject RedBall;
    public PlayerScript BlueBall;
    public float redmovetimer;
    public float bluemovetimer;
    public int stage = 0;
    public TMP_Text blueText;
    public TMP_Text redText;
    private bool prompt = false;
    public CameraZoom cam;

    public GameObject box;
    public GameObject promptbox;

    public AudioClip playerDisappointed;
    public AudioClip playerTalk;
    public AudioClip redStop;
    public GameObject music;

    // Update is called once per frame
    void Update()
    {
        if (redmovetimer <= 0)
        {
            FakeRedBall.rb.velocity = new Vector2(0f,0f);
        } else
        {
            redmovetimer -= Time.deltaTime;
        }
        if (bluemovetimer <= 0)
        {
            BlueBall.rb.velocity = new Vector2(0f, 0f);
        } else
        {
            bluemovetimer -= Time.deltaTime;
        }

        if (prompt == true)
        {
            if (stage > 17)
            {
                promptbox.transform.position = Vector3.Lerp(promptbox.transform.position, new Vector3(0f, -3f, 0f), 0.125f);
                box.transform.position = Vector3.Lerp(box.transform.position, new Vector3(0f, -7f, 0f), 0.125f);
            } else
            {
                promptbox.transform.position = Vector3.Lerp(promptbox.transform.position, new Vector3(4f, -1f, 0f), 0.125f);
                box.transform.position = Vector3.Lerp(box.transform.position, new Vector3(4f, -7f, 0f), 0.125f);
            }
        }

        if (stage == 0)
        {
            Write(false, "are we there ????\n\nPress [E] to continue dialog", true);
        }

        if (stage == 2)
        {
            if (FakeRedBall.transform.position.x > 2)
            {
                FakeRedBall.transform.position = new Vector3(2, -0.5f, 0);
            }
            if (BlueBall.transform.position.x > 4.6)
            {
                BlueBall.transform.position = new Vector3(4.6f, -0.5f, 0);
            }
        }

        if (Input.GetKeyDown(KeyCode.E) && redmovetimer <= 0 && bluemovetimer <= 0)
        {
            stage += 1;
            if (stage == 1)
            {
                Write(true, "It's right over this way.", false);
            } else if (stage == 2)
            {
                Write(false, ":))))))))))", false);
                BlueBall.rb.velocity = new Vector2(BlueBall.speed * Time.deltaTime, 0f);
                FakeRedBall.rb.velocity = new Vector2(FakeRedBall.speed * Time.deltaTime, 0f);
                bluemovetimer = 2f;
                redmovetimer = 2f;
            } else if (stage == 3)
            {
                Write(true,"Alright, I'll check the cheese for ya.", false);
                BlueBall.sprite.GetComponent<SpriteRenderer>().flipX = true;
                if (FakeRedBall.transform.position.x > 2)
                {
                    FakeRedBall.transform.position = new Vector3(2, -0.5f, 0);
                }
                if (BlueBall.transform.position.x > 4.6)
                {
                    BlueBall.transform.position = new Vector3(4.6f, -0.5f, 0);
                }
            } else if (stage == 4)
            {
                Write(false, "oh", false);
                redmovetimer = 0.1f;
                bluemovetimer = 0.1f;
                FakeRedBall.rb.velocity = new Vector2(-FakeRedBall.speed * Time.deltaTime, 0f);
                BlueBall.rb.velocity = new Vector2(BlueBall.speed * Time.deltaTime, 0f);
                BlueBall.sprite.GetComponent<SpriteRenderer>().flipX = false;
            }
            else if (stage == 5)
            {
                Write(false, "yeah", false);
                redmovetimer = 0.1f;
                FakeRedBall.rb.velocity = new Vector2(FakeRedBall.speed * Time.deltaTime, 0f);
            }
            else if (stage == 6)
            {
                Write(false, "cheese", false);
                redmovetimer = 0.1f;
                FakeRedBall.rb.velocity = new Vector2(-FakeRedBall.speed * Time.deltaTime, 0f);
            }
            else if (stage == 7)
            {
                Write(false, "time", false);
                redmovetimer = 0.1f;
                FakeRedBall.rb.velocity = new Vector2(FakeRedBall.speed * Time.deltaTime, 0f);
            }
            else if (stage == 8)
            {
                Write(true, "Hey, bad news.", false);
                bluemovetimer = 0.1f;
                BlueBall.rb.velocity = new Vector2(-BlueBall.speed * Time.deltaTime, 0f);
                BlueBall.sprite.GetComponent<SpriteRenderer>().flipX = true;
            }
            else if (stage == 9)
            {
                Write(true, "I think they're out of cheese.", true);
            } else if (stage == 10)
            {
                Write(false, "gnnrhg but i want cheese", false);
                FakeRedBall.gameObject.SetActive(false);
                RedBall.SetActive(true);
                RedBall.GetComponent<Animator>().SetInteger("Anim",0);
            }
            else if (stage == 11)
            {
                Write(true, "I'm sorry, they just don't have any more.", false);
            }
            else if (stage == 12)
            {
                Write(false, "i", false);
            }
            else if (stage == 13)
            {
                Write(false, "want", false);
            }
            else if (stage == 14)
            {
                Write(false, "cheese", false);
            }
            else if (stage == 15)
            {
                Write(true, "It's fine bro, I have some at home-", true);
            }
            else if (stage == 16)
            {
                Write(false, "stop talking to me",false);
            }
            else if (stage == 17)
            {
                prompt = true;
            }
            else if (stage == 18)
            {
                BlueBall.talkIcon.Emit(1);
                GetComponent<AudioSource>().clip = playerTalk;
                GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
                GetComponent<AudioSource>().Play();
                RedBall.GetComponent<Animator>().SetInteger("Anim", 1);
                RedBall.GetComponent<AudioSource>().Play();
                RedBall.GetComponent<Rigidbody2D>().velocity = new Vector2(-350 * Time.deltaTime,0);
                cam.zoomed = false;
                music.SetActive(true);
                DontDestroyOnLoad(music);
                BlueBall.canmove = true;
            }
        }
    }

    private void Write(bool blue, string message, bool disappointed)
    {
        if (blue)
        {
            redText.gameObject.SetActive(false);
            blueText.gameObject.SetActive(true);
            blueText.text = message;
            if (disappointed)
            {
                GetComponent<AudioSource>().clip = playerDisappointed;
            } else
            {
                GetComponent<AudioSource>().clip = playerTalk;
            }
            GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
            GetComponent<AudioSource>().Play();
        } else
        {
            blueText.gameObject.SetActive(false);
            redText.gameObject.SetActive(true);
            redText.text = message;
            GetComponent<AudioSource>().clip = redStop;
            GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
            if (disappointed == false)
            {
                GetComponent<AudioSource>().Play();
            }
        }
    }
}
