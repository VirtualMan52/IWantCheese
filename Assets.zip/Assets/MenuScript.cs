﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    public string nextScene;
    public Animator anim;
    public float completionTimer = 0;
    public bool completed = false;
    public Animator transition;
    public AudioSource music;
    public AudioSource doorclose;

    private void Awake()
    {
        anim.SetInteger("Anim",1);
    }

    private void Update()
    {
        if (completed == true)
        {
            completionTimer += Time.deltaTime;
            music.volume = Mathf.Lerp(music.volume, 0, 0.125f);
            if (completionTimer >= 1.5f)
            {
                SceneManager.LoadScene(nextScene, LoadSceneMode.Single);
            }
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("a");
            completed = true;
            transition.SetBool("DoAnim", true);
            doorclose.Play();
        }
    }
}
