﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreamScript : MonoBehaviour
{
    public RedBallScript parent;
    public float knockForce;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<PersonScript>() != null)
        {
            PersonScript person = collision.gameObject.GetComponent<PersonScript>();
            person.state = "shocked";
            person.timer = 5f;
            person.rb.velocity = -(parent.transform.position - person.gameObject.transform.position).normalized * knockForce;
            person.sprite.GetComponent<SpriteRenderer>().sprite = person.disappointedSprites[Random.Range(0,person.disappointedSprites.Count)];
        }
        if (collision.gameObject.GetComponent<PlayerScript>() != null)
        {
            PlayerScript plr = collision.gameObject.GetComponent<PlayerScript>();
            plr.rb.velocity = -(parent.transform.position - plr.gameObject.transform.position).normalized * knockForce;
            plr.stuntimer = 1f;
        }
    }
}
