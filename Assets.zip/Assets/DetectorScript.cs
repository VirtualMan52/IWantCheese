﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectorScript : MonoBehaviour
{

    public RedBallScript parent;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<CommonActivationPoleScript>() != null)
        {
            parent.target = collision.gameObject;
            parent.state = "destroy";
        }
    }
}
