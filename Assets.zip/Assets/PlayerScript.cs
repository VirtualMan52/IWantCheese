﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    public float speed;
    public bool canmove = true;
    public Rigidbody2D rb;
    public GameObject sprite;
    public Animator anim;
    public ParticleSystem talkIcon;
    public float stuntimer = 0f;

    public Sprite disappointedSprite;
    public Sprite normalSprite;

    public AudioSource talkSound;
    public List<AudioClip> possibleTalkSounds;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (canmove == true && stuntimer <= 0)
        {
            rb.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * speed * Time.deltaTime, Input.GetAxisRaw("Vertical") * speed * Time.deltaTime);
            if (Input.GetAxisRaw("Horizontal") == 1)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = false;
            } else if (Input.GetAxisRaw("Horizontal") == -1)
            {
                sprite.GetComponent<SpriteRenderer>().flipX = true;
            }

            if (Input.GetAxisRaw("Horizontal") != 0 || Input.GetAxisRaw("Vertical") != 0)
            {
                anim.SetInteger("Anim", 1);
            } else
            {
                anim.SetInteger("Anim", 0);
            }
            if (Input.GetKeyDown(KeyCode.E))
            {
                talkIcon.Emit(1);
                talkSound.clip = possibleTalkSounds[Random.Range(0, possibleTalkSounds.Count)];
                talkSound.Play();
            }
            sprite.GetComponent<SpriteRenderer>().sprite = normalSprite;
        } else if (canmove == true && stuntimer > 0)
        {
            anim.SetInteger("Anim", 0);
            rb.velocity = Vector2.Lerp(rb.velocity, Vector2.zero, 0.09f);
            stuntimer -= Time.deltaTime;
            sprite.GetComponent<SpriteRenderer>().sprite = disappointedSprite;
        }
    }
}
