﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedBallScript : MonoBehaviour
{
    public float speed;
    public bool canmove = true;
    public Rigidbody2D rb;
    public GameObject sprite;
    public Animator anim;
    public ParticleSystem whatIcon;
    public GameObject plr;
    public string state = "shocked";
    public float animtimer;
    public float plrDistance;
    public LayerMask avoid;
    public GameObject destroyDetector;
    public float wantedDestroyDetectorRadius;
    public GameObject target;
    public float screamTimer;
    public GameObject screamDetector;
    public float wantedScreamRadius;
    public ParticleSystem screamShockwave;

    public AudioSource madSound;
    public AudioSource screamSound;
    public AudioSource stopSound;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && plr.GetComponent<PlayerScript>().canmove == true && state == "shocked" && (plr.transform.position - transform.position).magnitude < plrDistance)
        {
            state = "mad";
        } else if (Input.GetKeyDown(KeyCode.E) && plr.GetComponent<PlayerScript>().canmove == true && state == "shocked")
        {
            state = "what";
            whatIcon.Emit(1);
            animtimer = 0f;
        }

        if (state == "mad")
        {
            anim.SetInteger("Anim", 1);
            rb.velocity = Vector2.Lerp(rb.velocity, -(plr.transform.position - transform.position).normalized * speed * Time.deltaTime,0.125f);
            if ((plr.transform.position - transform.position).magnitude >= plrDistance)
            {
                state = "shocked";
                stopSound.Play();
            }
            destroyDetector.GetComponent<CircleCollider2D>().radius = Mathf.Lerp(destroyDetector.GetComponent<CircleCollider2D>().radius,wantedDestroyDetectorRadius,0.125f);
            if (madSound.isPlaying == false)
            {
                madSound.Play();
            }
        } else if (state == "shocked")
        {
            anim.SetInteger("Anim", 0);
            rb.velocity = Vector2.zero;
        } else if (state == "what")
        {
            anim.SetInteger("Anim", 4);
            animtimer = animtimer + Time.deltaTime;
            if (animtimer >= 2)
            {
                state = "shocked";
            }
        } else if (state == "destroy")
        {
            if (target.GetComponent<ObstacleScript>().active == true)
            {
                rb.velocity = Vector2.Lerp(rb.velocity, (target.transform.position - (transform.position - new Vector3(0,0.5f,0))).normalized * speed * Time.deltaTime, 0.125f);
            } else
            {
                state = "mad";
            }
            if (madSound.isPlaying == false)
            {
                madSound.Play();
            }
        } else if (state == "screaming")
        {
            rb.velocity = Vector2.zero;
            screamTimer -= Time.deltaTime;
            screamDetector.GetComponent<CircleCollider2D>().radius = Mathf.Lerp(screamDetector.GetComponent<CircleCollider2D>().radius, wantedScreamRadius, 0.125f);
            if (screamTimer <= 0)
            {
                state = "mad";
            }
        }

        if (state != "mad")
        {
            destroyDetector.GetComponent<CircleCollider2D>().radius = 0;
            if (state != "destroy")
            {
                madSound.Stop();
            }
        }
        if (state != "screaming")
        {
            screamDetector.GetComponent<CircleCollider2D>().radius = 0;
        }

        if (rb.velocity.x > 0)
        {
            sprite.GetComponent<SpriteRenderer>().flipX = false;
        }
        else if (rb.velocity.x < 0)
        {
            sprite.GetComponent<SpriteRenderer>().flipX = true;
        }

        bool up = Physics2D.OverlapCircle(transform.position + new Vector3(0f,0f,0f), 0.75f, avoid);
        bool down = Physics2D.OverlapCircle(transform.position + new Vector3(0f, -1f, 0f), 0.75f, avoid);
        bool right = Physics2D.OverlapCircle(transform.position + new Vector3(0.5f, -0.5f, 0f), 0.75f, avoid);
        bool left = Physics2D.OverlapCircle(transform.position + new Vector3(-0.5f, -0.5f, 0f), 0.75f, avoid);

        if (up || down)
        {
            rb.velocity = new Vector2(rb.velocity.x, -rb.velocity.y);
            if (up)
            {
                rb.velocity -= Vector2.up;
            } else
            {
                rb.velocity += Vector2.up;
            }
        }
        if (left || right)
        {
            rb.velocity = new Vector2(-rb.velocity.x, rb.velocity.y);
            if (right)
            {
                rb.velocity -= Vector2.right;
            }
            else
            {
                rb.velocity += Vector2.right;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerScript>())
        {
            screamTimer = 1f;
            state = "screaming";
            anim.SetInteger("Anim",2);
            screamShockwave.Emit(1);
            screamSound.Play();
        }
    }
}
