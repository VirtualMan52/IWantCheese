﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TimerScript : MonoBehaviour
{
    public GameObject SceneTransition;
    public GameObject SceneChanger;
    public float TimeLeft;
    public bool restarted = false;
    public TMP_Text countdown;
    public GameObject gameovertext;

    private void Update()
    {
        if (restarted == false && TimeLeft <= 0.5f)
        {
            restarted = true;
            SceneChanger.GetComponent<SceneChangerScript>().RestartLevel = true;
            SceneTransition.GetComponent<Animator>().SetBool("DoAnim", true);
            gameovertext.SetActive(true);
        } else
        {
            TimeLeft -= Time.deltaTime;
            if (TimeLeft < 0)
            {
                TimeLeft = 0;
            }
            int minutes = Mathf.FloorToInt(TimeLeft / 60);
            int seconds = Mathf.FloorToInt(TimeLeft % 60);
            string timestring = string.Format("{0:00}:{1:00}", minutes, seconds);
            countdown.text = timestring;
        }
    }
}
