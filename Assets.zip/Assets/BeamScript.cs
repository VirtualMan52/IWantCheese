﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeamScript : MonoBehaviour
{
    public List<ObstacleScript> conditions;
    public Collider2D coll;
    public bool active = false;
    public Vector3 normalscale;
    public Vector3 openscale;
    public bool vertical = false;
    public bool or = false;

    public AudioSource source;
    public AudioClip hold;
    public AudioClip release;

    public void Awake()
    {
        normalscale = transform.localScale;
        if (vertical)
        {
            openscale = new Vector3(0f,normalscale.y,normalscale.z);
        } else
        {
            openscale = new Vector3(normalscale.x, 0f, normalscale.z);
        }
    }

    private void Update()
    {
        bool yes = false;
        if (or == false)
        {
            yes = false;
            foreach (ObstacleScript ob in conditions)
            {
                if (ob.active == true)
                {
                    yes = true;
                }
            }
        } else
        {
            yes = true;
            foreach (ObstacleScript ob in conditions)
            {
                if (ob.active == false)
                {
                    yes = false;
                }
            }
        }
        if (yes == active)
        {
            coll.enabled = false;
            transform.localScale = Vector3.Lerp(transform.localScale,openscale,0.125f);
            if (source.clip != hold)
            {
                source.clip = hold;
                source.Play();
            }
        }
        else
        {
            coll.enabled = true;
            transform.localScale = Vector3.Lerp(transform.localScale,normalscale, 0.125f);
            if (source.clip != release)
            {
                source.clip = release;
                source.Play();
            }
        }
    }
}
