﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EndingScript : MonoBehaviour
{
    public PlayerScript FakeRedBall;
    public GameObject blueContainer;
    public GameObject RedBall;
    public PlayerScript BlueBall;
    public float redmovetimer;
    public float bluemovetimer;
    public int stage = 0;
    public TMP_Text blueText;
    public TMP_Text redText;
    public CameraZoom cam;
    public Sprite normalSprite;
    public Sprite disappointedSprite;
    public ParticleSystem WhatIcon;
    public Rigidbody2D redrb;
    public GameObject cheese;

    public GameObject box;

    public AudioClip playerDisappointed;
    public AudioClip playerTalk;
    public AudioClip redStop;
    public AudioClip redballScream;
    public GameObject music;
    public GameObject oldMusic;

    private void Awake()
    {
        BlueBall.rb.velocity = new Vector2(-BlueBall.speed*Time.deltaTime,0f);
        bluemovetimer = 1f;
        oldMusic = GameObject.Find("Music");
    }

    void Update()
    {
        if (oldMusic != null)
        {
            oldMusic.GetComponent<AudioSource>().volume = Mathf.Lerp(oldMusic.GetComponent<AudioSource>().volume,0,0.125f);
            if (oldMusic.GetComponent<AudioSource>().volume < 0.01f)
            {
                oldMusic.GetComponent<AudioSource>().volume = 0;
                Destroy(oldMusic);
            }
        }
        if (redmovetimer <= 0)
        {
            FakeRedBall.rb.velocity = new Vector2(0f, 0f);
            redrb.velocity = new Vector2(0f, 0f);
            if (stage >= 13)
            {
                music.SetActive(true);
            }
        }
        else
        {
            redmovetimer -= Time.deltaTime;
        }
        if (bluemovetimer <= 0)
        {
            BlueBall.rb.velocity = new Vector2(0f, 0f);
        }
        else
        {
            if (stage != 0)
            {
                bluemovetimer -= Time.deltaTime;
            }
        }
        if (stage == 0 || stage == 6)
        {
            box.transform.position = Vector3.Lerp(box.transform.position, new Vector3(0f, -7f, 0f), 0.125f);
        }
        else
        {
            box.transform.position = Vector3.Lerp(box.transform.position, new Vector3(0f, -0f, 0f), 0.125f);
        }
        if (BlueBall.transform.position.x <= 2.5f)
        {
            bluemovetimer = 0f;
            if (stage == 0)
            {
                BlueBall.transform.position = new Vector3(2.5f, 0f, 0f);
            }
        }

        if (Input.GetKeyDown(KeyCode.E) && redmovetimer <= 0 && bluemovetimer <= 0)
        {
            stage += 1;
            if (stage == 1)
            {
                if (BlueBall.transform.position.x <= 2.5f)
                {
                    BlueBall.transform.position = new Vector3(2.5f,0f,0f);
                }
                Write(true, "Are you okay ?", true);
            }
            else if (stage == 2)
            {
                Write(false, "no", false);
            } else if (stage == 3)
            {
                Write(true, "Please.", true);
            }
            else if (stage == 4)
            {
                Write(false, ">:(", false);
            }
            else if (stage == 5)
            {
                BlueBall.sprite.GetComponent<SpriteRenderer>().sprite = normalSprite;
                Write(true, "Wait !", false);
            }
            else if (stage == 6)
            {
                RedBall.GetComponent<Animator>().SetInteger("Anim", 4);
                WhatIcon.Emit(1);
                BlueBall.sprite.GetComponent<SpriteRenderer>().flipX = false;
                blueContainer.GetComponent<Animator>().SetBool("Anim", true);
            }
            else if (stage == 7)
            {
                BlueBall.sprite.GetComponent<SpriteRenderer>().flipX = true;
                Write(true, "I remembered I brought some in case we were hungry.", false);
                cheese.SetActive(true);
            }
            else if (stage == 8)
            {
                FakeRedBall.gameObject.SetActive(true);
                RedBall.SetActive(false);
                Write(false, "wait", false);
            }
            else if (stage == 9)
            {
                Write(false, "so you're telling me", false);
            }
            else if (stage == 10)
            {
                Write(false, "that you had the cheese this whole time", false);
            }
            else if (stage == 11)
            {
                Write(true, "I told you I had some at home.", false);
            }
            else if (stage == 12)
            {
                FakeRedBall.gameObject.SetActive(false);
                RedBall.SetActive(true);
                RedBall.GetComponent<Animator>().SetInteger("Anim", 0);
                Write(false, "...", false);
                RedBall.transform.GetChild(0).GetComponent<SpriteRenderer>().flipX = false;
            }
            else if (stage == 13)
            {
                GetComponent<AudioSource>().clip = redballScream;
                GetComponent<AudioSource>().pitch = 1f;
                music.GetComponent<AudioSource>().time = 5.27f;
                GetComponent<AudioSource>().Play();
                RedBall.GetComponent<Animator>().SetInteger("Anim", 1);
                redrb.velocity = new Vector2(1000 * Time.deltaTime,0f);
                redmovetimer = 0.1f;
            }
        }

        //BlueBall.rb.velocity = new Vector2(BlueBall.speed * Time.deltaTime, 0f);
        //FakeRedBall.rb.velocity = new Vector2(FakeRedBall.speed * Time.deltaTime, 0f);
        //bluemovetimer = 2f;
        //redmovetimer = 2f;
    }

    private void Write(bool blue, string message, bool disappointed)
    {
        if (blue)
        {
            redText.gameObject.SetActive(false);
            blueText.gameObject.SetActive(true);
            blueText.text = message;
            if (disappointed)
            {
                GetComponent<AudioSource>().clip = playerDisappointed;
            }
            else
            {
                GetComponent<AudioSource>().clip = playerTalk;
            }
            GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
            GetComponent<AudioSource>().Play();
        }
        else
        {
            blueText.gameObject.SetActive(false);
            redText.gameObject.SetActive(true);
            redText.text = message;
            GetComponent<AudioSource>().clip = redStop;
            GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
            if (disappointed == false)
            {
                GetComponent<AudioSource>().Play();
            }
        }
    }
}
