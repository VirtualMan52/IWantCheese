﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PillarIntro : MonoBehaviour
{
    public List<string> Dialog;
    public int curDialog = 0;
    public TMP_Text text;
    public GameObject box;
    public PlayerScript plr;
    public GameObject prompt;

    private void Update()
    {
        if (curDialog < Dialog.Count)
        {
            text.text = Dialog[curDialog];
            if (Input.GetKeyDown(KeyCode.E))
            {
                curDialog += 1;
                if (curDialog < Dialog.Count)
                {
                    GetComponent<AudioSource>().pitch = Random.Range(0.8f, 1.2f);
                    GetComponent<AudioSource>().Play();
                } else
                {
                    plr.canmove = true;
                }
            }
        } else
        {
            box.transform.position = Vector3.Lerp(box.transform.position, new Vector3(0f, -6f, 0f), 0.125f);
            prompt.transform.position = Vector3.Lerp(prompt.transform.position, new Vector3(0f, -3f, 0f), 0.125f);
        }
    }
}
