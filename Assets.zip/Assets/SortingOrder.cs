﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SortingOrder : MonoBehaviour
{
    [SerializeField] private int baseLayer = 5000;
    [SerializeField] private float offset = 0;
    [SerializeField] private bool runOnce = true;
    private int five = 5;
    [SerializeField] List<GameObject> plus = null;
    [SerializeField] GameObject parent = null;
    private Renderer myRenderer;

    private void Awake()
    {
        myRenderer = GetComponent<Renderer>();
    }

    private void LateUpdate()
    {
        myRenderer.sortingOrder = (int)(baseLayer - (parent.transform.position.y + offset)*2);
        if (plus.Count > 0)
        {
            foreach (GameObject p in plus)
            {
                p.GetComponent<Renderer>().sortingOrder = myRenderer.sortingOrder;
            }
        }
        
        if (runOnce == true)
        {
            five += 1;
            if (five <= 0)
            {
                Destroy(this);
            }
        }
    }
}
