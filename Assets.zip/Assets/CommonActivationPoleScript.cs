﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CommonActivationPoleScript : MonoBehaviour
{
    public int hp;
    public SpriteRenderer sprite;
    public Sprite sprite0;
    public Sprite sprite1;
    public Sprite sprite2;
    public Sprite sprite3;

    public AudioSource source;
    public AudioClip destroyClip;

    public void Update()
    {
        if (hp == 3)
        {
            sprite.sprite = sprite3;
        } else if (hp == 2)
        {
            sprite.sprite = sprite2;
        }
        else if (hp == 1)
        {
            sprite.sprite = sprite1;
        }
        else
        {
            sprite.sprite = sprite0;
            GetComponent<BoxCollider2D>().enabled = false;
            GetComponent<ObstacleScript>().active = false;
            Destroy(this);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<RedBallScript>() != null)
        {
            RedBallScript script = collision.gameObject.GetComponent<RedBallScript>();
            script.rb.velocity = -(transform.position - (collision.gameObject.transform.position - new Vector3(0, 0.5f, 0))).normalized * 20;
            hp -= 1;
            if (hp > 0)
            {
                source.Play();
            } else
            {
                source.clip = destroyClip;
                source.Play();
            }
        }
    }
}
