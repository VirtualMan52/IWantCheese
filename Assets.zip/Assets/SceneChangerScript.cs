﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChangerScript : MonoBehaviour
{
    public bool CompletedLevel = false;
    public bool RestartLevel = false;
    public string nextScene;
    private float completionTimer = 0f;
    public GameObject transition;
    public GameObject RedBall;
    public bool finalLevel = false;
    public DoorScript door;

    public AudioSource source;
    public AudioClip hold;

    private void Update()
    {
        if (CompletedLevel == true)
        {
            completionTimer += Time.deltaTime;
            if (completionTimer >= 1.5f)
            {
                SceneManager.LoadScene(nextScene,LoadSceneMode.Single);  
            }
            if (RedBall != null)
            {
                foreach (AudioSource s in RedBall.GetComponents<AudioSource>())
                {
                    s.volume = Mathf.Lerp(RedBall.GetComponent<AudioSource>().volume, 0, 0.125f);
                }
            }
        }
        if (RestartLevel == true)
        {
            completionTimer += Time.deltaTime;
            if (completionTimer >= 1.5f)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name, LoadSceneMode.Single);
            }
            if (RedBall != null)
            {
                foreach (AudioSource s in RedBall.GetComponents<AudioSource>())
                {
                    s.volume = Mathf.Lerp(RedBall.GetComponent<AudioSource>().volume, 0, 0.125f);
                }
            }
        }
        if (Input.GetKeyDown(KeyCode.R) && RestartLevel == false)
        {
            RestartLevel = true;
            if (transition.activeSelf == true)
            {
                transition.GetComponent<Animator>().SetBool("DoAnim", true);
                source.clip = hold;
                source.Play();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerScript>() != null && door.isOpen == true)
        {
            CompletedLevel = true;
            collision.gameObject.GetComponent<PlayerScript>().canmove = false;
            if (!finalLevel)
            {
                collision.gameObject.GetComponent<PlayerScript>().rb.velocity = -Vector2.right * 3;
                collision.gameObject.GetComponent<PlayerScript>().anim.SetInteger("Anim", 1);
            } else
            {
                collision.gameObject.GetComponent<PlayerScript>().rb.velocity = Vector2.up * 3;
                collision.gameObject.GetComponent<PlayerScript>().anim.SetInteger("Anim", 1);
            }
            if (transition.activeSelf == true)
            {
                transition.GetComponent<Animator>().SetBool("DoAnim", true);
                source.clip = hold;
                source.Play();
            }
        }
    }
}
