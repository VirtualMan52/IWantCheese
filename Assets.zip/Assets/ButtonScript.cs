﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    public bool touchingPlayer = false;
    public bool touchingRedBall = false;
    public Sprite normalSprite;
    public Sprite heldSprite;
    public GameObject sprite;

    public AudioSource source;
    public AudioClip hold;
    public AudioClip release;

    private void Update()
    {
        if (touchingPlayer || touchingRedBall)
        {
            GetComponent<ObstacleScript>().active = false;
            sprite.GetComponent<SpriteRenderer>().sprite = heldSprite;
            if (source.clip == hold)
            {
                source.clip = release;
                source.Play();
            }
        } else
        {
            GetComponent<ObstacleScript>().active = true;
            sprite.GetComponent<SpriteRenderer>().sprite = normalSprite;
            if (source.clip == release)
            {
                source.clip = hold;
                source.Play();
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerScript>() != null)
        {
            touchingPlayer = true;
        }
        if (collision.gameObject.GetComponent<RedBallScript>() != null)
        {
            touchingRedBall = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerScript>() != null)
        {
            touchingPlayer = false;
        }
        if (collision.gameObject.GetComponent<RedBallScript>() != null)
        {
            touchingRedBall = false;
        }
    }
}
