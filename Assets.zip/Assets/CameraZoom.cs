﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    public bool zoomed;
    public Vector3 zoomPosition;
    public float zoomScale;
    public Vector3 normalPosition;
    public float normalScale;
    public GameObject Cam;

    public void Awake()
    {
        if (zoomed)
        {
            Cam.transform.position = zoomPosition;
            Cam.GetComponent<Camera>().orthographicSize = zoomScale;
        }
        else
        {
            Cam.transform.position = Vector3.Lerp(Cam.transform.position, normalPosition, 0.125f);
            Cam.GetComponent<Camera>().orthographicSize = Mathf.Lerp(Cam.GetComponent<Camera>().orthographicSize, normalScale, 0.125f);
        }
    }

    void Update()
    {
        if (zoomed)
        {
            Cam.transform.position = Vector3.Lerp(Cam.transform.position,zoomPosition,0.125f);
            Cam.GetComponent<Camera>().orthographicSize = Mathf.Lerp(Cam.GetComponent<Camera>().orthographicSize,zoomScale,0.125f);
        } else
        {
            Cam.transform.position = Vector3.Lerp(Cam.transform.position, normalPosition, 0.125f);
            Cam.GetComponent<Camera>().orthographicSize = Mathf.Lerp(Cam.GetComponent<Camera>().orthographicSize, normalScale, 0.125f);
        }
    }
}
