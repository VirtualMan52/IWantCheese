﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TipScript : MonoBehaviour
{
    public float time;
    public TMP_Text tip;

    void Update()
    {
        if (time >= 30)
        {
            tip.color = Color.Lerp(tip.color,new Color(1f,1f,1f,0.5f),0.125f);
        } else
        {
            time += Time.deltaTime;
        }
    }
}
