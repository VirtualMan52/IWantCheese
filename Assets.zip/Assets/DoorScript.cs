﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScript : MonoBehaviour
{
    public List<ObstacleScript> obstacles;
    public Animator anim;
    public BoxCollider2D coll;
    public bool isOpen;

    public AudioSource source;
    public AudioClip hold;
    public AudioClip release;

    private void Awake()
    {
        if (obstacles.Count > 0)
        {
            source.clip = release;
        }
    }

    private void Update()
    {
        bool yes = false;
        if (obstacles.Count > 0)
        {
            foreach (ObstacleScript ob in obstacles)
            {
                if (ob.active == true)
                {
                    yes = true;
                }
            }
        }
        if (yes == false)
        {
            isOpen = true;
            coll.enabled = false;
            anim.SetBool("Open", true);
            if (source.clip != hold)
            {
                source.clip = hold;
                source.Play();
            }
        } else
        {
            isOpen = false;
            coll.enabled = true;
            anim.SetBool("Open", false);
            if (source.clip != release)
            {
                source.clip = release;
                source.Play();
            }
        }
    }
}
